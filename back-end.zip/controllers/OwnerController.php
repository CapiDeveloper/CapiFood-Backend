<?php

namespace Controllers;

class OwnerController {
    // Crear vistas de reportes y otros
}