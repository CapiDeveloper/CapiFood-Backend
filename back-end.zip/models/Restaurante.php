<?php

namespace Model;

class Restaurante extends ActiveRecord{

    public static $tabla = 'restaurante';
    public static $columnasDB = ['id','nombre','ciudad', 'direccion', 
    'telefono', 'logo', 'ruc','id_usuario'];

    public $id;
    public $nombre;
    public $ciudad;
    public $direccion;
    public $telefono;
    public $logo;
    public $ruc;
    public $id_usuario;

    public function __construct($args=[]){
        $this->id = $args['id'] ?? null;
        $this->nombre = $args['nombre'] ?? '';
        $this->ciudad = $args['ciudad'] ?? '';
        $this->direccion = $args['direccion'] ?? '';
        $this->telefono = $args['telefono'] ?? '';
        $this->logo = $args['logo'] ?? '';
        $this->ruc = $args['ruc'] ?? '';
        $this->id_usuario = $args['id_usuario'] ?? null;
    }
}
?>